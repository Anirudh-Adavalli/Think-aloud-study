
public class Tree {
	float height;
}
