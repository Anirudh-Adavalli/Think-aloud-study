
public class Sound {
	int frequencyInHertz;
}
