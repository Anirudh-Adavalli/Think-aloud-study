
public class Movement {
	float velocity;
}
