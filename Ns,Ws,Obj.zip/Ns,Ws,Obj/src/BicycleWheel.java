
public class BicycleWheel {
	float radiusInInch;
}
