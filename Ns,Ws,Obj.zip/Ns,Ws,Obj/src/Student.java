
public class Student {
	int age;
	String residentCity;

}
