
public class WaterBottle {
	float contentInLiter;
}
