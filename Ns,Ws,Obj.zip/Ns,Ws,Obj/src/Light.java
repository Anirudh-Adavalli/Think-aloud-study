
public class Light {
	float illuminance;
}
