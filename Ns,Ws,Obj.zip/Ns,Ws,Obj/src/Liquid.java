
public class Liquid {
	float density;
}
