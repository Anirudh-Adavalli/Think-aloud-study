
public class Rotation {
	int byDegree;
}
